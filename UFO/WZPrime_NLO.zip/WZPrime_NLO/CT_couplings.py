# This file was automatically created by FeynRules 2.3.29
# Mathematica version: 10.3.1 for Mac OS X x86 (64-bit) (December 9, 2015)
# Date: Thu 24 May 2018 18:51:12


from object_library import all_couplings, Coupling

from function_library import complexconjugate, re, im, csc, sec, acsc, asec, cot



R2GC_100_1 = Coupling(name = 'R2GC_100_1',
                      value = '(cw*ee*complex(0,1)*G**2)/(12.*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*sw)/(36.*cw*cmath.pi**2)',
                      order = {'QCD':2,'QED':1})

R2GC_101_2 = Coupling(name = 'R2GC_101_2',
                      value = '(ee**2*complex(0,1)*G**2)/(96.*cmath.pi**2*sw**2)',
                      order = {'QCD':2,'QED':2})

R2GC_102_3 = Coupling(name = 'R2GC_102_3',
                      value = '-(cw*ee*complex(0,1)*G**2)/(12.*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*sw)/(36.*cw*cmath.pi**2)',
                      order = {'QCD':2,'QED':1})

R2GC_115_4 = Coupling(name = 'R2GC_115_4',
                      value = '-G**4/(192.*cmath.pi**2)',
                      order = {'QCD':4})

R2GC_115_5 = Coupling(name = 'R2GC_115_5',
                      value = 'G**4/(64.*cmath.pi**2)',
                      order = {'QCD':4})

R2GC_116_6 = Coupling(name = 'R2GC_116_6',
                      value = '-(complex(0,1)*G**4)/(192.*cmath.pi**2)',
                      order = {'QCD':4})

R2GC_116_7 = Coupling(name = 'R2GC_116_7',
                      value = '(complex(0,1)*G**4)/(64.*cmath.pi**2)',
                      order = {'QCD':4})

R2GC_117_8 = Coupling(name = 'R2GC_117_8',
                      value = '(complex(0,1)*G**4)/(192.*cmath.pi**2)',
                      order = {'QCD':4})

R2GC_117_9 = Coupling(name = 'R2GC_117_9',
                      value = '-(complex(0,1)*G**4)/(64.*cmath.pi**2)',
                      order = {'QCD':4})

R2GC_118_10 = Coupling(name = 'R2GC_118_10',
                       value = '-(complex(0,1)*G**4)/(48.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_119_11 = Coupling(name = 'R2GC_119_11',
                       value = '(complex(0,1)*G**4)/(288.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_119_12 = Coupling(name = 'R2GC_119_12',
                       value = '-(complex(0,1)*G**4)/(32.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_120_13 = Coupling(name = 'R2GC_120_13',
                       value = '-(complex(0,1)*G**4)/(16.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_120_14 = Coupling(name = 'R2GC_120_14',
                       value = '(complex(0,1)*G**4)/(4.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_121_15 = Coupling(name = 'R2GC_121_15',
                       value = '(-3*complex(0,1)*G**4)/(64.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_121_16 = Coupling(name = 'R2GC_121_16',
                       value = '(-23*complex(0,1)*G**4)/(64.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_122_17 = Coupling(name = 'R2GC_122_17',
                       value = '(complex(0,1)*G**2)/(12.*cmath.pi**2)',
                       order = {'QCD':2})

R2GC_123_18 = Coupling(name = 'R2GC_123_18',
                       value = '(ee*complex(0,1)*G**2)/(18.*cmath.pi**2)',
                       order = {'QCD':2,'QED':1})

R2GC_125_19 = Coupling(name = 'R2GC_125_19',
                       value = '-(complex(0,1)*G**3)/(6.*cmath.pi**2)',
                       order = {'QCD':3})

R2GC_127_20 = Coupling(name = 'R2GC_127_20',
                       value = '-(ee*complex(0,1)*G**2)/(9.*cmath.pi**2)',
                       order = {'QCD':2,'QED':1})

R2GC_144_21 = Coupling(name = 'R2GC_144_21',
                       value = '-(complex(0,1)*G**2*gwp)/(6.*cmath.pi**2)',
                       order = {'BSM':1,'QCD':2})

R2GC_145_22 = Coupling(name = 'R2GC_145_22',
                       value = '-(ee*complex(0,1)*G**2)/(6.*cmath.pi**2*sw*cmath.sqrt(2))',
                       order = {'QCD':2,'QED':1})

R2GC_146_23 = Coupling(name = 'R2GC_146_23',
                       value = '-(delbs*complex(0,1)*G**2*gb)/(6.*cmath.pi**2)',
                       order = {'BSM':1,'QCD':2})

R2GC_148_24 = Coupling(name = 'R2GC_148_24',
                       value = '(complex(0,1)*G**2)/(48.*cmath.pi**2)',
                       order = {'QCD':2})

R2GC_148_25 = Coupling(name = 'R2GC_148_25',
                       value = '(3*complex(0,1)*G**2)/(32.*cmath.pi**2)',
                       order = {'QCD':2})

R2GC_149_26 = Coupling(name = 'R2GC_149_26',
                       value = '-(complex(0,1)*G**2)/(16.*cmath.pi**2)',
                       order = {'QCD':2})

R2GC_150_27 = Coupling(name = 'R2GC_150_27',
                       value = 'G**3/(24.*cmath.pi**2)',
                       order = {'QCD':3})

R2GC_150_28 = Coupling(name = 'R2GC_150_28',
                       value = '(11*G**3)/(64.*cmath.pi**2)',
                       order = {'QCD':3})

R2GC_153_29 = Coupling(name = 'R2GC_153_29',
                       value = '-G**3/(24.*cmath.pi**2)',
                       order = {'QCD':3})

R2GC_153_30 = Coupling(name = 'R2GC_153_30',
                       value = '(-11*G**3)/(64.*cmath.pi**2)',
                       order = {'QCD':3})

R2GC_156_31 = Coupling(name = 'R2GC_156_31',
                       value = '(5*complex(0,1)*G**4)/(48.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_156_32 = Coupling(name = 'R2GC_156_32',
                       value = '(19*complex(0,1)*G**4)/(32.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_157_33 = Coupling(name = 'R2GC_157_33',
                       value = '(23*complex(0,1)*G**4)/(192.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_158_34 = Coupling(name = 'R2GC_158_34',
                       value = '(31*complex(0,1)*G**4)/(64.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_159_35 = Coupling(name = 'R2GC_159_35',
                       value = '(-17*complex(0,1)*G**4)/(64.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_160_36 = Coupling(name = 'R2GC_160_36',
                       value = '(-7*complex(0,1)*G**4)/(32.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_161_37 = Coupling(name = 'R2GC_161_37',
                       value = '(7*complex(0,1)*G**4)/(64.*cmath.pi**2)',
                       order = {'QCD':4})

R2GC_165_38 = Coupling(name = 'R2GC_165_38',
                       value = '-(complex(0,1)*G**2*gb)/(6.*cmath.pi**2)',
                       order = {'BSM':1,'QCD':2})

R2GC_166_39 = Coupling(name = 'R2GC_166_39',
                       value = '(complex(0,1)*G**2*MT)/(6.*cmath.pi**2)',
                       order = {'QCD':2})

R2GC_169_40 = Coupling(name = 'R2GC_169_40',
                       value = '(ee*complex(0,1)*G**2*sw)/(9.*cw*cmath.pi**2)',
                       order = {'QCD':2,'QED':1})

R2GC_170_41 = Coupling(name = 'R2GC_170_41',
                       value = '(G**2*yt)/(3.*cmath.pi**2)',
                       order = {'QCD':2,'QED':1})

R2GC_171_42 = Coupling(name = 'R2GC_171_42',
                       value = '-(G**2*yt)/(3.*cmath.pi**2)',
                       order = {'QCD':2,'QED':1})

R2GC_172_43 = Coupling(name = 'R2GC_172_43',
                       value = '(G**2*yt)/(3.*cmath.pi**2*cmath.sqrt(2))',
                       order = {'QCD':2,'QED':1})

R2GC_173_44 = Coupling(name = 'R2GC_173_44',
                       value = '(complex(0,1)*G**2*yt)/(3.*cmath.pi**2*cmath.sqrt(2))',
                       order = {'QCD':2,'QED':1})

R2GC_75_45 = Coupling(name = 'R2GC_75_45',
                      value = '-(complex(0,1)*G**2*MT**2)/(8.*cmath.pi**2)',
                      order = {'QCD':2})

R2GC_76_46 = Coupling(name = 'R2GC_76_46',
                      value = '-(complex(0,1)*G**2*MT*yt)/(8.*cmath.pi**2*cmath.sqrt(2))',
                      order = {'QCD':2,'QED':1})

R2GC_77_47 = Coupling(name = 'R2GC_77_47',
                      value = '-(complex(0,1)*G**2*yt**2)/(16.*cmath.pi**2)',
                      order = {'QCD':2,'QED':2})

R2GC_79_48 = Coupling(name = 'R2GC_79_48',
                      value = '-(ee*complex(0,1)*G**2*sw)/(18.*cw*cmath.pi**2)',
                      order = {'QCD':2,'QED':1})

R2GC_80_49 = Coupling(name = 'R2GC_80_49',
                      value = '(complex(0,1)*G**2*gwp**2)/(48.*cmath.pi**2)',
                      order = {'BSM':2,'QCD':2})

R2GC_86_50 = Coupling(name = 'R2GC_86_50',
                      value = '-(ee*complex(0,1)*G**2*gb)/(144.*cmath.pi**2)',
                      order = {'BSM':1,'QCD':2,'QED':1})

R2GC_86_51 = Coupling(name = 'R2GC_86_51',
                      value = '(ee*complex(0,1)*G**2*gb)/(72.*cmath.pi**2)',
                      order = {'BSM':1,'QCD':2,'QED':1})

R2GC_87_52 = Coupling(name = 'R2GC_87_52',
                      value = '(complex(0,1)*G**3*gb)/(96.*cmath.pi**2)',
                      order = {'BSM':1,'QCD':3})

R2GC_88_53 = Coupling(name = 'R2GC_88_53',
                      value = '-(complex(0,1)*G**3*gb)/(32.*cmath.pi**2)',
                      order = {'BSM':1,'QCD':3})

R2GC_89_54 = Coupling(name = 'R2GC_89_54',
                      value = '-(cw*ee*complex(0,1)*G**2*gb)/(96.*cmath.pi**2*sw) - (ee*complex(0,1)*G**2*gb*sw)/(288.*cw*cmath.pi**2)',
                      order = {'BSM':1,'QCD':2,'QED':1})

R2GC_89_55 = Coupling(name = 'R2GC_89_55',
                      value = '(cw*ee*complex(0,1)*G**2*gb)/(96.*cmath.pi**2*sw) - (ee*complex(0,1)*G**2*gb*sw)/(288.*cw*cmath.pi**2)',
                      order = {'BSM':1,'QCD':2,'QED':1})

R2GC_90_56 = Coupling(name = 'R2GC_90_56',
                      value = '(ee**2*complex(0,1)*G**2)/(216.*cmath.pi**2)',
                      order = {'QCD':2,'QED':2})

R2GC_90_57 = Coupling(name = 'R2GC_90_57',
                      value = '(ee**2*complex(0,1)*G**2)/(54.*cmath.pi**2)',
                      order = {'QCD':2,'QED':2})

R2GC_91_58 = Coupling(name = 'R2GC_91_58',
                      value = '-(ee*complex(0,1)*G**3)/(144.*cmath.pi**2)',
                      order = {'QCD':3,'QED':1})

R2GC_91_59 = Coupling(name = 'R2GC_91_59',
                      value = '(ee*complex(0,1)*G**3)/(72.*cmath.pi**2)',
                      order = {'QCD':3,'QED':1})

R2GC_92_60 = Coupling(name = 'R2GC_92_60',
                      value = '(cw*ee**2*complex(0,1)*G**2)/(288.*cmath.pi**2*sw) - (ee**2*complex(0,1)*G**2*sw)/(864.*cw*cmath.pi**2)',
                      order = {'QCD':2,'QED':2})

R2GC_92_61 = Coupling(name = 'R2GC_92_61',
                      value = '(cw*ee**2*complex(0,1)*G**2)/(144.*cmath.pi**2*sw) - (5*ee**2*complex(0,1)*G**2*sw)/(432.*cw*cmath.pi**2)',
                      order = {'QCD':2,'QED':2})

R2GC_93_62 = Coupling(name = 'R2GC_93_62',
                      value = '-(cw*ee*complex(0,1)*G**3)/(192.*cmath.pi**2*sw) + (ee*complex(0,1)*G**3*sw)/(576.*cw*cmath.pi**2)',
                      order = {'QCD':3,'QED':1})

R2GC_93_63 = Coupling(name = 'R2GC_93_63',
                      value = '(cw*ee*complex(0,1)*G**3)/(192.*cmath.pi**2*sw) - (5*ee*complex(0,1)*G**3*sw)/(576.*cw*cmath.pi**2)',
                      order = {'QCD':3,'QED':1})

R2GC_94_64 = Coupling(name = 'R2GC_94_64',
                      value = '(-3*cw*ee*complex(0,1)*G**3)/(64.*cmath.pi**2*sw) - (3*ee*complex(0,1)*G**3*sw)/(64.*cw*cmath.pi**2)',
                      order = {'QCD':3,'QED':1})

R2GC_94_65 = Coupling(name = 'R2GC_94_65',
                      value = '(3*cw*ee*complex(0,1)*G**3)/(64.*cmath.pi**2*sw) + (3*ee*complex(0,1)*G**3*sw)/(64.*cw*cmath.pi**2)',
                      order = {'QCD':3,'QED':1})

R2GC_95_66 = Coupling(name = 'R2GC_95_66',
                      value = '(ee**2*complex(0,1)*G**2)/(288.*cmath.pi**2) + (cw**2*ee**2*complex(0,1)*G**2)/(192.*cmath.pi**2*sw**2) + (5*ee**2*complex(0,1)*G**2*sw**2)/(1728.*cw**2*cmath.pi**2)',
                      order = {'QCD':2,'QED':2})

R2GC_95_67 = Coupling(name = 'R2GC_95_67',
                      value = '-(ee**2*complex(0,1)*G**2)/(288.*cmath.pi**2) + (cw**2*ee**2*complex(0,1)*G**2)/(192.*cmath.pi**2*sw**2) + (17*ee**2*complex(0,1)*G**2*sw**2)/(1728.*cw**2*cmath.pi**2)',
                      order = {'QCD':2,'QED':2})

R2GC_99_68 = Coupling(name = 'R2GC_99_68',
                      value = '(complex(0,1)*G**2*gb**2)/(48.*cmath.pi**2)',
                      order = {'BSM':2,'QCD':2})

R2GC_99_69 = Coupling(name = 'R2GC_99_69',
                      value = '(delbs**2*complex(0,1)*G**2*gb**2)/(24.*cmath.pi**2)',
                      order = {'BSM':2,'QCD':2})

UVGC_103_1 = Coupling(name = 'UVGC_103_1',
                      value = {-1:'-(complex(0,1)*G**2)/(12.*cmath.pi**2)'},
                      order = {'QCD':2})

UVGC_104_2 = Coupling(name = 'UVGC_104_2',
                      value = {-1:'-(ee*complex(0,1)*G**2)/(36.*cmath.pi**2)'},
                      order = {'QCD':2,'QED':1})

UVGC_106_3 = Coupling(name = 'UVGC_106_3',
                      value = {-1:'(ee*complex(0,1)*G**2)/(18.*cmath.pi**2)'},
                      order = {'QCD':2,'QED':1})

UVGC_113_4 = Coupling(name = 'UVGC_113_4',
                      value = {-1:'(9*G**3)/(128.*cmath.pi**2)'},
                      order = {'QCD':3})

UVGC_113_5 = Coupling(name = 'UVGC_113_5',
                      value = {-1:'-G**3/(128.*cmath.pi**2)'},
                      order = {'QCD':3})

UVGC_114_6 = Coupling(name = 'UVGC_114_6',
                      value = {-1:'(-9*G**3)/(128.*cmath.pi**2)'},
                      order = {'QCD':3})

UVGC_114_7 = Coupling(name = 'UVGC_114_7',
                      value = {-1:'G**3/(128.*cmath.pi**2)'},
                      order = {'QCD':3})

UVGC_115_8 = Coupling(name = 'UVGC_115_8',
                      value = {-1:'(3*G**4)/(512.*cmath.pi**2)'},
                      order = {'QCD':4})

UVGC_115_9 = Coupling(name = 'UVGC_115_9',
                      value = {-1:'(-3*G**4)/(512.*cmath.pi**2)'},
                      order = {'QCD':4})

UVGC_116_10 = Coupling(name = 'UVGC_116_10',
                       value = {-1:'(3*complex(0,1)*G**4)/(512.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_116_11 = Coupling(name = 'UVGC_116_11',
                       value = {-1:'(-3*complex(0,1)*G**4)/(512.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_118_12 = Coupling(name = 'UVGC_118_12',
                       value = {-1:'-(complex(0,1)*G**4)/(128.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_118_13 = Coupling(name = 'UVGC_118_13',
                       value = {-1:'(complex(0,1)*G**4)/(128.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_119_14 = Coupling(name = 'UVGC_119_14',
                       value = {-1:'(-3*complex(0,1)*G**4)/(256.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_119_15 = Coupling(name = 'UVGC_119_15',
                       value = {-1:'(3*complex(0,1)*G**4)/(256.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_120_16 = Coupling(name = 'UVGC_120_16',
                       value = {-1:'-(complex(0,1)*G**4)/(24.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_120_17 = Coupling(name = 'UVGC_120_17',
                       value = {-1:'(47*complex(0,1)*G**4)/(128.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_121_18 = Coupling(name = 'UVGC_121_18',
                       value = {-1:'(-253*complex(0,1)*G**4)/(512.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_121_19 = Coupling(name = 'UVGC_121_19',
                       value = {-1:'(5*complex(0,1)*G**4)/(512.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_122_20 = Coupling(name = 'UVGC_122_20',
                       value = {-1:'(complex(0,1)*G**2)/(12.*cmath.pi**2)'},
                       order = {'QCD':2})

UVGC_123_21 = Coupling(name = 'UVGC_123_21',
                       value = {-1:'(ee*complex(0,1)*G**2)/(36.*cmath.pi**2)'},
                       order = {'QCD':2,'QED':1})

UVGC_124_22 = Coupling(name = 'UVGC_124_22',
                       value = {-1:'(complex(0,1)*G**3)/(48.*cmath.pi**2)'},
                       order = {'QCD':3})

UVGC_124_23 = Coupling(name = 'UVGC_124_23',
                       value = {-1:'(-19*complex(0,1)*G**3)/(128.*cmath.pi**2)'},
                       order = {'QCD':3})

UVGC_124_24 = Coupling(name = 'UVGC_124_24',
                       value = {-1:'-(complex(0,1)*G**3)/(128.*cmath.pi**2)'},
                       order = {'QCD':3})

UVGC_124_25 = Coupling(name = 'UVGC_124_25',
                       value = {-1:'( 0 if MT else (complex(0,1)*G**3)/(48.*cmath.pi**2) )'},
                       order = {'QCD':3})

UVGC_124_26 = Coupling(name = 'UVGC_124_26',
                       value = {-1:'(complex(0,1)*G**3)/(12.*cmath.pi**2)'},
                       order = {'QCD':3})

UVGC_125_27 = Coupling(name = 'UVGC_125_27',
                       value = {-1:'(-13*complex(0,1)*G**3)/(48.*cmath.pi**2)'},
                       order = {'QCD':3})

UVGC_127_28 = Coupling(name = 'UVGC_127_28',
                       value = {-1:'-(ee*complex(0,1)*G**2)/(18.*cmath.pi**2)'},
                       order = {'QCD':2,'QED':1})

UVGC_144_29 = Coupling(name = 'UVGC_144_29',
                       value = {-1:'(complex(0,1)*G**2*gwp)/(24.*cmath.pi**2)'},
                       order = {'BSM':1,'QCD':2})

UVGC_144_30 = Coupling(name = 'UVGC_144_30',
                       value = {-1:'-(complex(0,1)*G**2*gwp)/(12.*cmath.pi**2)'},
                       order = {'BSM':1,'QCD':2})

UVGC_145_31 = Coupling(name = 'UVGC_145_31',
                       value = {-1:'(ee*complex(0,1)*G**2)/(24.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'QCD':2,'QED':1})

UVGC_145_32 = Coupling(name = 'UVGC_145_32',
                       value = {-1:'-(ee*complex(0,1)*G**2)/(12.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'QCD':2,'QED':1})

UVGC_146_33 = Coupling(name = 'UVGC_146_33',
                       value = {-1:'(delbs*complex(0,1)*G**2*gb)/(24.*cmath.pi**2)'},
                       order = {'BSM':1,'QCD':2})

UVGC_146_34 = Coupling(name = 'UVGC_146_34',
                       value = {-1:'-(delbs*complex(0,1)*G**2*gb)/(12.*cmath.pi**2)'},
                       order = {'BSM':1,'QCD':2})

UVGC_148_35 = Coupling(name = 'UVGC_148_35',
                       value = {-1:'( 0 if MT else -(complex(0,1)*G**2)/(24.*cmath.pi**2) ) + (complex(0,1)*G**2)/(24.*cmath.pi**2)',0:'( -(complex(0,1)*G**2*reglog(MT/MU_R))/(12.*cmath.pi**2) if MT else 0 )'},
                       order = {'QCD':2})

UVGC_149_36 = Coupling(name = 'UVGC_149_36',
                       value = {-1:'(3*complex(0,1)*G**2)/(64.*cmath.pi**2)'},
                       order = {'QCD':2})

UVGC_149_37 = Coupling(name = 'UVGC_149_37',
                       value = {-1:'(-3*complex(0,1)*G**2)/(64.*cmath.pi**2)'},
                       order = {'QCD':2})

UVGC_149_38 = Coupling(name = 'UVGC_149_38',
                       value = {-1:'( 0 if MT else (complex(0,1)*G**2)/(24.*cmath.pi**2) ) - (complex(0,1)*G**2)/(24.*cmath.pi**2)',0:'( (complex(0,1)*G**2*reglog(MT/MU_R))/(12.*cmath.pi**2) if MT else 0 )'},
                       order = {'QCD':2})

UVGC_150_39 = Coupling(name = 'UVGC_150_39',
                       value = {-1:'-G**3/(48.*cmath.pi**2)'},
                       order = {'QCD':3})

UVGC_150_40 = Coupling(name = 'UVGC_150_40',
                       value = {-1:'(51*G**3)/(128.*cmath.pi**2)'},
                       order = {'QCD':3})

UVGC_150_41 = Coupling(name = 'UVGC_150_41',
                       value = {-1:'( 0 if MT else -G**3/(16.*cmath.pi**2) ) + G**3/(24.*cmath.pi**2)',0:'( -(G**3*reglog(MT/MU_R))/(12.*cmath.pi**2) if MT else 0 )'},
                       order = {'QCD':3})

UVGC_151_42 = Coupling(name = 'UVGC_151_42',
                       value = {-1:'(21*G**3)/(64.*cmath.pi**2)'},
                       order = {'QCD':3})

UVGC_151_43 = Coupling(name = 'UVGC_151_43',
                       value = {-1:'G**3/(64.*cmath.pi**2)'},
                       order = {'QCD':3})

UVGC_152_44 = Coupling(name = 'UVGC_152_44',
                       value = {-1:'(33*G**3)/(128.*cmath.pi**2)'},
                       order = {'QCD':3})

UVGC_152_45 = Coupling(name = 'UVGC_152_45',
                       value = {-1:'(3*G**3)/(128.*cmath.pi**2)'},
                       order = {'QCD':3})

UVGC_153_46 = Coupling(name = 'UVGC_153_46',
                       value = {-1:'G**3/(48.*cmath.pi**2)'},
                       order = {'QCD':3})

UVGC_153_47 = Coupling(name = 'UVGC_153_47',
                       value = {-1:'(-33*G**3)/(128.*cmath.pi**2)'},
                       order = {'QCD':3})

UVGC_153_48 = Coupling(name = 'UVGC_153_48',
                       value = {-1:'(-3*G**3)/(128.*cmath.pi**2)'},
                       order = {'QCD':3})

UVGC_153_49 = Coupling(name = 'UVGC_153_49',
                       value = {-1:'( 0 if MT else G**3/(16.*cmath.pi**2) ) - G**3/(24.*cmath.pi**2)',0:'( (G**3*reglog(MT/MU_R))/(12.*cmath.pi**2) if MT else 0 )'},
                       order = {'QCD':3})

UVGC_154_50 = Coupling(name = 'UVGC_154_50',
                       value = {-1:'(-21*G**3)/(64.*cmath.pi**2)'},
                       order = {'QCD':3})

UVGC_154_51 = Coupling(name = 'UVGC_154_51',
                       value = {-1:'-G**3/(64.*cmath.pi**2)'},
                       order = {'QCD':3})

UVGC_155_52 = Coupling(name = 'UVGC_155_52',
                       value = {-1:'(-51*G**3)/(128.*cmath.pi**2)'},
                       order = {'QCD':3})

UVGC_156_53 = Coupling(name = 'UVGC_156_53',
                       value = {-1:'(147*complex(0,1)*G**4)/(128.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_156_54 = Coupling(name = 'UVGC_156_54',
                       value = {-1:'(3*complex(0,1)*G**4)/(128.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_156_55 = Coupling(name = 'UVGC_156_55',
                       value = {-1:'( 0 if MT else -(complex(0,1)*G**4)/(12.*cmath.pi**2) ) + (complex(0,1)*G**4)/(12.*cmath.pi**2)',0:'( -(complex(0,1)*G**4*reglog(MT/MU_R))/(12.*cmath.pi**2) if MT else 0 )'},
                       order = {'QCD':4})

UVGC_157_56 = Coupling(name = 'UVGC_157_56',
                       value = {-1:'(147*complex(0,1)*G**4)/(512.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_157_57 = Coupling(name = 'UVGC_157_57',
                       value = {-1:'(21*complex(0,1)*G**4)/(512.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_158_58 = Coupling(name = 'UVGC_158_58',
                       value = {-1:'-(complex(0,1)*G**4)/(12.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_158_59 = Coupling(name = 'UVGC_158_59',
                       value = {-1:'(523*complex(0,1)*G**4)/(512.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_158_60 = Coupling(name = 'UVGC_158_60',
                       value = {-1:'(13*complex(0,1)*G**4)/(512.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_158_61 = Coupling(name = 'UVGC_158_61',
                       value = {-1:'( 0 if MT else -(complex(0,1)*G**4)/(12.*cmath.pi**2) )',0:'( -(complex(0,1)*G**4*reglog(MT/MU_R))/(12.*cmath.pi**2) if MT else 0 )'},
                       order = {'QCD':4})

UVGC_159_62 = Coupling(name = 'UVGC_159_62',
                       value = {-1:'(complex(0,1)*G**4)/(24.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_159_63 = Coupling(name = 'UVGC_159_63',
                       value = {-1:'(-341*complex(0,1)*G**4)/(512.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_159_64 = Coupling(name = 'UVGC_159_64',
                       value = {-1:'(-11*complex(0,1)*G**4)/(512.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_159_65 = Coupling(name = 'UVGC_159_65',
                       value = {-1:'( 0 if MT else (complex(0,1)*G**4)/(12.*cmath.pi**2) ) - (complex(0,1)*G**4)/(24.*cmath.pi**2)',0:'( (complex(0,1)*G**4*reglog(MT/MU_R))/(12.*cmath.pi**2) if MT else 0 )'},
                       order = {'QCD':4})

UVGC_160_66 = Coupling(name = 'UVGC_160_66',
                       value = {-1:'(-83*complex(0,1)*G**4)/(128.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_160_67 = Coupling(name = 'UVGC_160_67',
                       value = {-1:'(-5*complex(0,1)*G**4)/(128.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_161_68 = Coupling(name = 'UVGC_161_68',
                       value = {-1:'(complex(0,1)*G**4)/(12.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_161_69 = Coupling(name = 'UVGC_161_69',
                       value = {-1:'(-85*complex(0,1)*G**4)/(512.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_161_70 = Coupling(name = 'UVGC_161_70',
                       value = {-1:'(-19*complex(0,1)*G**4)/(512.*cmath.pi**2)'},
                       order = {'QCD':4})

UVGC_161_71 = Coupling(name = 'UVGC_161_71',
                       value = {-1:'( 0 if MT else (complex(0,1)*G**4)/(12.*cmath.pi**2) )',0:'( (complex(0,1)*G**4*reglog(MT/MU_R))/(12.*cmath.pi**2) if MT else 0 )'},
                       order = {'QCD':4})

UVGC_162_72 = Coupling(name = 'UVGC_162_72',
                       value = {-1:'( (complex(0,1)*G**2)/(6.*cmath.pi**2) if MT else -(complex(0,1)*G**2)/(12.*cmath.pi**2) ) + (complex(0,1)*G**2)/(12.*cmath.pi**2)',0:'( (5*complex(0,1)*G**2)/(12.*cmath.pi**2) - (complex(0,1)*G**2*reglog(MT/MU_R))/(2.*cmath.pi**2) if MT else (complex(0,1)*G**2)/(12.*cmath.pi**2) ) - (complex(0,1)*G**2)/(12.*cmath.pi**2)'},
                       order = {'QCD':2})

UVGC_163_73 = Coupling(name = 'UVGC_163_73',
                       value = {-1:'( -(ee*complex(0,1)*G**2)/(9.*cmath.pi**2) if MT else (ee*complex(0,1)*G**2)/(18.*cmath.pi**2) )',0:'( (-5*ee*complex(0,1)*G**2)/(18.*cmath.pi**2) + (ee*complex(0,1)*G**2*reglog(MT/MU_R))/(3.*cmath.pi**2) if MT else -(ee*complex(0,1)*G**2)/(18.*cmath.pi**2) ) + (ee*complex(0,1)*G**2)/(18.*cmath.pi**2)'},
                       order = {'QCD':2,'QED':1})

UVGC_164_74 = Coupling(name = 'UVGC_164_74',
                       value = {-1:'( -(complex(0,1)*G**3)/(6.*cmath.pi**2) if MT else (complex(0,1)*G**3)/(12.*cmath.pi**2) )',0:'( (-5*complex(0,1)*G**3)/(12.*cmath.pi**2) + (complex(0,1)*G**3*reglog(MT/MU_R))/(2.*cmath.pi**2) if MT else -(complex(0,1)*G**3)/(12.*cmath.pi**2) ) + (complex(0,1)*G**3)/(12.*cmath.pi**2)'},
                       order = {'QCD':3})

UVGC_165_75 = Coupling(name = 'UVGC_165_75',
                       value = {-1:'( -(complex(0,1)*G**2*gb)/(6.*cmath.pi**2) if MT else (complex(0,1)*G**2*gb)/(12.*cmath.pi**2) ) - (complex(0,1)*G**2*gb)/(12.*cmath.pi**2)',0:'( (-5*complex(0,1)*G**2*gb)/(12.*cmath.pi**2) + (complex(0,1)*G**2*gb*reglog(MT/MU_R))/(2.*cmath.pi**2) if MT else -(complex(0,1)*G**2*gb)/(12.*cmath.pi**2) ) + (complex(0,1)*G**2*gb)/(12.*cmath.pi**2)'},
                       order = {'BSM':1,'QCD':2})

UVGC_166_76 = Coupling(name = 'UVGC_166_76',
                       value = {-1:'( (complex(0,1)*G**2*MT)/(6.*cmath.pi**2) if MT else -(complex(0,1)*G**2*MT)/(12.*cmath.pi**2) ) + (complex(0,1)*G**2*MT)/(3.*cmath.pi**2)',0:'( (3*complex(0,1)*G**2*MT)/(4.*cmath.pi**2) - (complex(0,1)*G**2*MT*reglog(MT/MU_R))/cmath.pi**2 if MT else (complex(0,1)*G**2*MT)/(12.*cmath.pi**2) ) - (complex(0,1)*G**2*MT)/(12.*cmath.pi**2)'},
                       order = {'QCD':2})

UVGC_167_77 = Coupling(name = 'UVGC_167_77',
                       value = {-1:'( -(ee*complex(0,1)*G**2)/(12.*cmath.pi**2*sw*cmath.sqrt(2)) if MT else (ee*complex(0,1)*G**2)/(24.*cmath.pi**2*sw*cmath.sqrt(2)) )',0:'( (-5*ee*complex(0,1)*G**2)/(24.*cmath.pi**2*sw*cmath.sqrt(2)) + (ee*complex(0,1)*G**2*reglog(MT/MU_R))/(4.*cmath.pi**2*sw*cmath.sqrt(2)) if MT else -(ee*complex(0,1)*G**2)/(24.*cmath.pi**2*sw*cmath.sqrt(2)) ) + (ee*complex(0,1)*G**2)/(24.*cmath.pi**2*sw*cmath.sqrt(2))'},
                       order = {'QCD':2,'QED':1})

UVGC_168_78 = Coupling(name = 'UVGC_168_78',
                       value = {-1:'( -(cw*ee*complex(0,1)*G**2)/(12.*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*sw)/(36.*cw*cmath.pi**2) if MT else (cw*ee*complex(0,1)*G**2)/(24.*cmath.pi**2*sw) - (ee*complex(0,1)*G**2*sw)/(72.*cw*cmath.pi**2) ) - (cw*ee*complex(0,1)*G**2)/(24.*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*sw)/(72.*cw*cmath.pi**2)',0:'( (-5*cw*ee*complex(0,1)*G**2)/(24.*cmath.pi**2*sw) + (5*ee*complex(0,1)*G**2*sw)/(72.*cw*cmath.pi**2) + (cw*ee*complex(0,1)*G**2*reglog(MT/MU_R))/(4.*cmath.pi**2*sw) - (ee*complex(0,1)*G**2*sw*reglog(MT/MU_R))/(12.*cw*cmath.pi**2) if MT else -(cw*ee*complex(0,1)*G**2)/(24.*cmath.pi**2*sw) + (ee*complex(0,1)*G**2*sw)/(72.*cw*cmath.pi**2) ) + (cw*ee*complex(0,1)*G**2)/(24.*cmath.pi**2*sw) - (ee*complex(0,1)*G**2*sw)/(72.*cw*cmath.pi**2)'},
                       order = {'QCD':2,'QED':1})

UVGC_169_79 = Coupling(name = 'UVGC_169_79',
                       value = {-1:'( (ee*complex(0,1)*G**2*sw)/(9.*cw*cmath.pi**2) if MT else -(ee*complex(0,1)*G**2*sw)/(18.*cw*cmath.pi**2) ) + (ee*complex(0,1)*G**2*sw)/(18.*cw*cmath.pi**2)',0:'( (5*ee*complex(0,1)*G**2*sw)/(18.*cw*cmath.pi**2) - (ee*complex(0,1)*G**2*sw*reglog(MT/MU_R))/(3.*cw*cmath.pi**2) if MT else (ee*complex(0,1)*G**2*sw)/(18.*cw*cmath.pi**2) ) - (ee*complex(0,1)*G**2*sw)/(18.*cw*cmath.pi**2)'},
                       order = {'QCD':2,'QED':1})

UVGC_170_80 = Coupling(name = 'UVGC_170_80',
                       value = {-1:'-(G**2*yt)/(24.*cmath.pi**2)'},
                       order = {'QCD':2,'QED':1})

UVGC_170_81 = Coupling(name = 'UVGC_170_81',
                       value = {-1:'( (G**2*yt)/(12.*cmath.pi**2) if MT else -(G**2*yt)/(24.*cmath.pi**2) )',0:'( (13*G**2*yt)/(24.*cmath.pi**2) - (3*G**2*yt*reglog(MT/MU_R))/(4.*cmath.pi**2) if MT else (G**2*yt)/(24.*cmath.pi**2) ) - (G**2*yt)/(24.*cmath.pi**2)'},
                       order = {'QCD':2,'QED':1})

UVGC_170_82 = Coupling(name = 'UVGC_170_82',
                       value = {-1:'(G**2*yt)/(3.*cmath.pi**2)'},
                       order = {'QCD':2,'QED':1})

UVGC_171_83 = Coupling(name = 'UVGC_171_83',
                       value = {-1:'(G**2*yt)/(24.*cmath.pi**2)'},
                       order = {'QCD':2,'QED':1})

UVGC_171_84 = Coupling(name = 'UVGC_171_84',
                       value = {-1:'( -(G**2*yt)/(12.*cmath.pi**2) if MT else (G**2*yt)/(24.*cmath.pi**2) )',0:'( (-13*G**2*yt)/(24.*cmath.pi**2) + (3*G**2*yt*reglog(MT/MU_R))/(4.*cmath.pi**2) if MT else -(G**2*yt)/(24.*cmath.pi**2) ) + (G**2*yt)/(24.*cmath.pi**2)'},
                       order = {'QCD':2,'QED':1})

UVGC_171_85 = Coupling(name = 'UVGC_171_85',
                       value = {-1:'-(G**2*yt)/(3.*cmath.pi**2)'},
                       order = {'QCD':2,'QED':1})

UVGC_172_86 = Coupling(name = 'UVGC_172_86',
                       value = {-1:'( (G**2*yt)/(6.*cmath.pi**2*cmath.sqrt(2)) if MT else -(G**2*yt)/(12.*cmath.pi**2*cmath.sqrt(2)) ) + (G**2*yt)/(3.*cmath.pi**2*cmath.sqrt(2))',0:'( (3*G**2*yt)/(4.*cmath.pi**2*cmath.sqrt(2)) - (G**2*yt*reglog(MT/MU_R))/(cmath.pi**2*cmath.sqrt(2)) if MT else (G**2*yt)/(12.*cmath.pi**2*cmath.sqrt(2)) ) - (G**2*yt)/(12.*cmath.pi**2*cmath.sqrt(2))'},
                       order = {'QCD':2,'QED':1})

UVGC_173_87 = Coupling(name = 'UVGC_173_87',
                       value = {-1:'( (complex(0,1)*G**2*yt)/(6.*cmath.pi**2*cmath.sqrt(2)) if MT else -(complex(0,1)*G**2*yt)/(12.*cmath.pi**2*cmath.sqrt(2)) ) + (complex(0,1)*G**2*yt)/(3.*cmath.pi**2*cmath.sqrt(2))',0:'( (3*complex(0,1)*G**2*yt)/(4.*cmath.pi**2*cmath.sqrt(2)) - (complex(0,1)*G**2*yt*reglog(MT/MU_R))/(cmath.pi**2*cmath.sqrt(2)) if MT else (complex(0,1)*G**2*yt)/(12.*cmath.pi**2*cmath.sqrt(2)) ) - (complex(0,1)*G**2*yt)/(12.*cmath.pi**2*cmath.sqrt(2))'},
                       order = {'QCD':2,'QED':1})

